# Preferencias de usuario

Este es el repositorio del proyecto de preferencias de usuario para el manejo de información persistente en el dispositivo sin usar SQLite.